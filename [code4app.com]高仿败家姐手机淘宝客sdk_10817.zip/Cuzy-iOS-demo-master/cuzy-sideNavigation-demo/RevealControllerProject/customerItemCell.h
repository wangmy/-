//
//  customerItemCell.h
//  RevealControllerProject
//
//  Created by Alex on 13-5-28.
//
//

#import <UIKit/UIKit.h>

@interface customerItemCell : UITableViewCell
{
    
}



@end
