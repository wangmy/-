//
//  settingAboutViewController.h
//  RevealControllerProject
//
//  Created by Apple on 13-5-31.
//
//

#import <UIKit/UIKit.h>

@interface settingAboutViewController : UIViewController
{
    
}
@property (retain, nonatomic) IBOutlet UIImageView *logoimage;

@end
