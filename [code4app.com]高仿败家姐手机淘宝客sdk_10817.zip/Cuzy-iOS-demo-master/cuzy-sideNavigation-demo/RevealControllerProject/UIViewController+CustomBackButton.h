
#import <UIKit/UIKit.h>

@interface UIViewController (CustomBackButton)

-(void)addNavigationCutomizedBack;
-(void)addNavigationCutomizedBackNone;

@end
