//
//  SettingViewController.h
//  RevealControllerProject
//
//  Created by Apple on 13-5-31.
//
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController
{
    
}

@property (retain, nonatomic) IBOutlet UITableView *tableRef;

@end
